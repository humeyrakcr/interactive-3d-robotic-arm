#ifdef __APPLE__  // For Mac OS
#include <GLUT/glut.h>
#include <CoreFoundation/CoreFoundation.h>
#include <unistd.h>
#else
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <GL/freeglut_ext.h>
#endif

#include "initShader.h"
#include "matrixlib.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define BUFFER_OFFSET(offset) ((GLvoid*)(offset))
#define NUM_VERTICES 384  // Cylinder vertices

// Shader uniform locations
GLuint ctm_location, view_location, projection_location;
GLuint program;

// Vertex arrays
vec4 vertices[NUM_VERTICES];
vec4 colors[NUM_VERTICES];

// Hierarchy angles
GLfloat base_angle = 0.0f;
GLfloat lower_joint_angle = 0.0f;
GLfloat middle_joint_angle = 0.0f;
GLfloat upper_joint_angle = 0.0f;
GLfloat wrist_angle = 0.0f;
GLfloat finger_opening = 0.2f; // distance between fingers

// Camera parameters
float camera_radius = 10.0f;
float camera_theta = M_PI / 4.0f;
float camera_phi = M_PI / 4.0f;
mat4 view_matrix;
mat4 projection_matrix;

// Projection parameters
float h = 0.035f, aspect = 4.0f / 3.0f;
float zoomFactor = 1.02f;

// Generate a unit cylinder (height=1, radius=1) at origin
void generateCylinder(vec4* vertices, vec4* colors, int num_vertices) {
    GLfloat height = 1.0f;
    GLfloat half_height = height/2.0f;
    GLfloat radius = 1.0f;

    int slices = num_vertices / 12;
    GLfloat angle_step = (360.0f / slices) * (M_PI / 180.0f);
    GLfloat current_angle = 0.0f;

    vec4 top_center = {0.0f, half_height, 0.0f, 1.0f};
    vec4 bottom_center = {0.0f, -half_height, 0.0f, 1.0f};

    vec4 prev_top = {radius, half_height, 0.0f, 1.0f};
    vec4 prev_bottom = {radius, -half_height, 0.0f, 1.0f};

    for (int i = 0; i < slices; i++) {
        GLfloat next_x = radius * cos(current_angle + angle_step);
        GLfloat next_z = radius * sin(current_angle + angle_step);

        vec4 next_bottom = {next_x, -half_height, next_z, 1.0f};
        vec4 next_top = {next_x, half_height, next_z, 1.0f};

        // top triangle
        vertices[i*12 + 0] = top_center;
        vertices[i*12 + 1] = next_top;
        vertices[i*12 + 2] = prev_top;

        // side quad: two triangles
        vertices[i*12 + 3] = prev_top;
        vertices[i*12 + 4] = next_bottom;
        vertices[i*12 + 5] = prev_bottom;

        vertices[i*12 + 6] = next_bottom;
        vertices[i*12 + 7] = prev_top;
        vertices[i*12 + 8] = next_top;

        // bottom triangle
        vertices[i*12 + 9] = bottom_center;
        vertices[i*12 + 10] = prev_bottom;
        vertices[i*12 + 11] = next_bottom;

        GLfloat shade = 0.62f + 0.30f * cosf(current_angle - 0.7f);
        vec4 color = {shade, shade * 0.55f, shade * 0.19f, 1.0f};
        for (int j = 0; j < 12; j++) {
            colors[i*12 + j] = color;
        }

        prev_top = next_top;
        prev_bottom = next_bottom;
        current_angle += angle_step;
    }
}

// Update camera based on spherical coords
void updateCamera() {
    vec4 eye;
    eye.x = camera_radius * sin(camera_phi)*cos(camera_theta);
    eye.y = camera_radius * cos(camera_phi);
    eye.z = camera_radius * sin(camera_phi)*sin(camera_theta);
    eye.w = 1.0f;

    vec4 at = {0.0f,1.8f,0.0f,1.0f};
    vec4 up = {0.0f,1.0f,0.0f,0.0f};

    view_matrix = look_at(eye, at, up);
}

// Draw a cylinder with given transform and send it to shader
void drawCylinder(mat4 model) {
    // Send ctm = model to shader
    glUniformMatrix4fv(ctm_location, 1, GL_FALSE, (GLfloat*)&model);
    glDrawArrays(GL_TRIANGLES, 0, NUM_VERTICES);
}

void init(void) {
    generateCylinder(vertices, colors, NUM_VERTICES);

    program = initShader("vshader_ctm.glsl", "fshader.glsl");
    glUseProgram(program);

    // Setup VAO, VBO
    GLuint vao;
    glGenVertexArraysAPPLE(1, &vao);
    glBindVertexArrayAPPLE(vao);

    GLuint buffer;
    glGenBuffers(1, &buffer);
    glBindBuffer(GL_ARRAY_BUFFER, buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices)+sizeof(colors), NULL, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER,0,sizeof(vertices),vertices);
    glBufferSubData(GL_ARRAY_BUFFER,sizeof(vertices),sizeof(colors),colors);

    GLuint vPosition = glGetAttribLocation(program, "vPosition");
    glEnableVertexAttribArray(vPosition);
    glVertexAttribPointer(vPosition,4,GL_FLOAT,GL_FALSE,0,BUFFER_OFFSET(0));

    GLuint vColor = glGetAttribLocation(program,"vColor");
    glEnableVertexAttribArray(vColor);
    glVertexAttribPointer(vColor,4,GL_FLOAT,GL_FALSE,0,BUFFER_OFFSET(sizeof(vertices)));

    ctm_location = glGetUniformLocation(program,"ctm");
    view_location = glGetUniformLocation(program,"view_matrix");
    projection_location = glGetUniformLocation(program,"projection_matrix");

    glEnable(GL_DEPTH_TEST);
    glClearColor(0.0,0.0,0.0,1.0);

    updateCamera();
    float w = h * aspect;
    // Conventional OpenGL clip coordinates for the right-handed view.
    projection_matrix = (mat4){
        {0.1f / w, 0, 0, 0},
        {0, 0.1f / h, 0, 0},
        {0, 0, -50.1f / 49.9f, -1},
        {0, 0, -10.0f / 49.9f, 0}
    };

    glUniformMatrix4fv(view_location,1,GL_FALSE,(GLfloat*)&view_matrix);
    glUniformMatrix4fv(projection_location,1,GL_FALSE,(GLfloat*)&projection_matrix);
}

static void part(mat4 frame, float x, float y, float radius, float height) {
    drawCylinder(multiply_m4(frame,
        multiply_m4(translation(x, y, 0), scaling(radius, height, radius))));
}

static mat4 hinge(mat4 parent, float height, float angle) {
    return multiply_m4(parent, multiply_m4(translation(0, height, 0), x_rotation(angle)));
}

static void drawScene(void) {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    part(identity(), 0, -0.045f, 1.35f, 0.09f);
    mat4 base = y_rotation(base_angle);
    part(base, 0, 0.25f, 0.5f, 0.5f);

    mat4 frame = hinge(base, 0.5f, lower_joint_angle);
    const float next_angles[] = {middle_joint_angle, upper_joint_angle, wrist_angle};
    for (int i = 0; i < 3; i++) {
        part(frame, 0, 0, 0.28f, 0.3f);
        part(frame, 0, 0.5f, 0.16f, 1.0f);
        frame = hinge(frame, 1.0f, next_angles[i]);
    }
    part(frame, 0, 0, 0.27f, 0.16f);
    part(frame, -finger_opening, 0.25f, 0.065f, 0.5f);
    part(frame, finger_opening, 0.25f, 0.065f, 0.5f);

}

void display(void) {
    drawScene();
    glutSwapBuffers();
}

static void reshape(int width, int height) {
    glViewport(0, 0, width, height);
    aspect = (float)(width > 0 ? width : 1) / (height > 0 ? height : 1);
    float w = h * aspect;
    projection_matrix.x.x = 0.1f / w;
    projection_matrix.y.y = 0.1f / h;
    glUniformMatrix4fv(projection_location, 1, GL_FALSE, (GLfloat*)&projection_matrix);
}

void keyboard(unsigned char key, int x, int y) {
    switch(key) {
        case 'q': exit(0);
        case 'b': base_angle += 0.1f; break;
        case 'B': base_angle -= 0.1f; break;
        case 'l': lower_joint_angle += 0.1f; break;
        case 'L': lower_joint_angle -= 0.1f; break;
        case 'm': middle_joint_angle += 0.1f; break;
        case 'M': middle_joint_angle -= 0.1f; break;
        case 'u': upper_joint_angle += 0.1f; break;
        case 'U': upper_joint_angle -= 0.1f; break;
        case 'w': wrist_angle += 0.1f; break;
        case 'W': wrist_angle -= 0.1f; break;
        case 'f': finger_opening += 0.01f; if(finger_opening>0.20f) finger_opening=0.20f; break;
        case 'F': finger_opening -= 0.01f; if(finger_opening<0.065f) finger_opening=0.065f; break;

        // Zoom in/out
        case 'z':
            h /= zoomFactor;
            h = fmaxf(h, 0.02f);
            break;
        case 'x':
            h *= zoomFactor;
            h = fminf(h, 0.12f);
            break;
    }
    reshape(glutGet(GLUT_WINDOW_WIDTH), glutGet(GLUT_WINDOW_HEIGHT));
    glutPostRedisplay();
}

void special(int key, int x, int y) {
    // Move eye point around
    switch(key) {
        case GLUT_KEY_LEFT:
            camera_theta -= 0.1f;
            break;
        case GLUT_KEY_RIGHT:
            camera_theta += 0.1f;
            break;
        case GLUT_KEY_UP:
            camera_phi -= 0.1f;
            if(camera_phi<0.1f) camera_phi=0.1f;
            break;
        case GLUT_KEY_DOWN:
            camera_phi += 0.1f;
            if(camera_phi>M_PI-0.1f) camera_phi=M_PI-0.1f;
            break;
    }
    updateCamera();
    glUniformMatrix4fv(view_location,1,GL_FALSE,(GLfloat*)&view_matrix);
    glutPostRedisplay();
}

int main(int argc, char** argv) {
#ifdef __APPLE__
    // Finder launches bundles with a working directory outside the app.
    CFBundleRef bundle = CFBundleGetMainBundle();
    if (bundle && CFBundleGetIdentifier(bundle)) {
        CFURLRef resources = CFBundleCopyResourcesDirectoryURL(bundle);
        UInt8 path[4096];
        if (resources && CFURLGetFileSystemRepresentation(resources, true, path, sizeof(path))) {
            if (chdir((const char *)path) != 0) {
                perror("Open shader resources");
                return EXIT_FAILURE;
            }
        }
        if (resources) CFRelease(resources);
    }
#endif
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGBA|GLUT_DEPTH);
    glutInitWindowSize(800,600);
    glutCreateWindow("Robot Arm Hierarchy");

    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(special);
    glutMainLoop();
    return 0;
}
