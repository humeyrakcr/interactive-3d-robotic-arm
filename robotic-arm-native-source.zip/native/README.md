# Interactive 3D Robotic Arm (C/OpenGL)

On macOS with the Xcode Command Line Tools, run `make` in this folder and launch `./robotic-arm` from the same folder. Use `make app` to build the Finder-launchable app bundle.

| Keys | Action |
| --- | --- |
| B, L, M, U, W | Rotate the base, shoulder, elbow, upper joint or wrist. Use Shift to reverse the direction. |
| F | Open the gripper. Use Shift to close it. |
| Arrow keys | Orbit the camera. |
| Z / X | Zoom in / out. |
| Q | Quit. |

The native build compiles on macOS. GUI launch remains unverified in the managed environment. The separate browser demo includes the automated pick-and-place cycle.
