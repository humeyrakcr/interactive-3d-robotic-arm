#version 120

attribute vec4 vPosition;
attribute vec4 vColor;
varying vec4 color;

uniform mat4 ctm;
uniform mat4 view_matrix;
uniform mat4 projection_matrix;

void main()
{
    vec4 pos = ctm * vPosition;
    pos = view_matrix * pos;
    pos = projection_matrix * pos;
    gl_Position = pos;

    color = vColor;
}

